package com.lqr.wechat.nimsdk.custom;

/**
 * @创建者 CSDN_LQR
 * @描述 自定消息类型
 */
public interface CustomAttachmentType {
    // 多端统一
    int Guess = 1;//猜拳
    int SnapChat = 2;
    int Sticker = 3;
    int RTS = 4;
}
