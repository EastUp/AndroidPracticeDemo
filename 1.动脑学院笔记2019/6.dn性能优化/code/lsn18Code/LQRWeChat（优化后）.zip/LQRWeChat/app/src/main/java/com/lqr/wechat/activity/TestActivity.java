package com.lqr.wechat.activity;


import com.lqr.wechat.R;

/**
 * @创建者 CSDN_LQR
 * @描述 用于测试的界面
 */
public class TestActivity extends BaseActivity {


    @Override
    public void initView() {
        setContentView(R.layout.activity_test);
    }

}
